package com.bsoandroid.foodapp;

import android.content.Context;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;

public class FoodData {
    public static ArrayList<Food> getData(Context context) {
        ArrayList<Food> list = new ArrayList<Food>();
        list.add(new Food("Batagor", "Terbuat dari daging ayam dan saus kacang istimewa", 10000, context.getDrawable(R.drawable.batagor)));
        list.add(new Food("Cireng", "Cireng Garut dengan lumuran bumbu rujak", 8000, context.getDrawable(R.drawable.cireng)));
        list.add(new Food("Tea", "Tea Melati Pilihan dengan extrax Lemon yang menyegarkan", 10000, context.getDrawable(R.drawable.sparkling_tea)));
        list.add(new Food("Cheesecake", "Texture kue yang lembut dan keju yang creammy", 27000, context.getDrawable(R.drawable.cheesecake)));
        return list;
    }
}
